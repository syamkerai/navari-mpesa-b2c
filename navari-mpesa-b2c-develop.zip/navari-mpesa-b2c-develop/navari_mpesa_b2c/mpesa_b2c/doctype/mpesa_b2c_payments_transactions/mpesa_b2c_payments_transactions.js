// Copyright (c) 2023, Navari Ltd and contributors
// For license information, please see license.txt

// frappe.ui.form.on("MPesa B2C Payments Transactions", {
// 	refresh(frm) {

// 	},
// });
